#include <stdio.h>

int main()
{
    double radius, area;
    const double PI = 3.14159265358979;

    printf("Enter the radius of the circle: ");
    if (scanf("%lf", &radius) != 1 || radius < 0) {
        printf("Please enter a valid positive number.\n");
        return 1;
    }

    area = PI * radius * radius;

    printf("The area of the circle is: %.2f\n", area);

    return 0;
}
